package models;

public class Equipment extends InventoryItem {
    
    private String assetId;
    private String brand;
    private String category;
    private int warrantyMonths;
    
    public Equipment(String assetId, String name, String brand, boolean isAvailable, 
                     String category, int warrantyMonths) {
        super(assetId, name, isAvailable);
        this.assetId = assetId;
        this.brand = brand;
        this.category = category;
        this.warrantyMonths = warrantyMonths;
    }
    
    public String getItemType() {
        return "Equipment";
    }
    
    public String getAssetId() {
        return assetId;
    }
    
    public void setAssetId(String assetId) {
        this.assetId = assetId;
        this.id = assetId;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public int getWarrantyMonths() {
        return warrantyMonths;
    }
    
    public void setWarrantyMonths(int warrantyMonths) {
        this.warrantyMonths = warrantyMonths;
    }
    
    public boolean isWarrantyExpired() {
        return warrantyMonths == 0;
    }
    
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Equipment other = (Equipment) obj;
        if (this.assetId == null) {
            return other.assetId == null;
        }
        return this.assetId.equals(other.assetId);
    }
    
    public String toString() {
        String warrantyStatus;
        if (warrantyMonths > 0) {
            warrantyStatus = warrantyMonths + " months";
        } else {
            warrantyStatus = "Expired";
        }
        
        return "=== Equipment Details ===\n" +
               "Asset ID: " + assetId + "\n" +
               "Name: " + name + "\n" +
               "Brand: " + brand + "\n" +
               "Category: " + category + "\n" +
               "Available: " + (isAvailable ? "Yes" : "No") + "\n" +
               "Warranty: " + warrantyStatus;
    }
}
