import models.Equipment;
import models.StaffMember;
import managers.InventoryManager;
import managers.InventoryReports;
import exceptions.InventoryException;

import java.util.Scanner;
import java.util.List;

public class UniversityInventorySystem {
    
    public static void main(String[] args) {
        InventoryManager inventoryManager = new InventoryManager();
        InventoryReports inventoryReports = new InventoryReports(inventoryManager);
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        
        System.out.println("=====================================");
        System.out.println("  UNIVERSITY INVENTORY MANAGEMENT");
        System.out.println("=====================================");
        
        while (running) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Add new equipment");
            System.out.println("2. Register a new staff member");
            System.out.println("3. Assign equipment to staff");
            System.out.println("4. Return equipment");
            System.out.println("5. Search inventory");
            System.out.println("6. Generate reports");
            System.out.println("7. Exit system");
            System.out.print("Enter choice: ");
            
            int choice = 0;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }
            
            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter Asset ID: ");
                        String assetId = scanner.nextLine();
                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Brand: ");
                        String brand = scanner.nextLine();
                        System.out.print("Enter Category: ");
                        String category = scanner.nextLine();
                        System.out.print("Enter Warranty Months: ");
                        int warranty = Integer.parseInt(scanner.nextLine());
                        
                        Equipment equipment = new Equipment(assetId, name, brand, true, category, warranty);
                        inventoryManager.addEquipment(equipment);
                        System.out.println("Equipment added successfully!");
                    } catch (NumberFormatException e) {
                        System.out.println("Error: Invalid warranty months.");
                    }
                    break;
                    
                case 2:
                    try {
                        System.out.print("Enter Staff ID: ");
                        int staffId = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter Name: ");
                        String staffName = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter Department: ");
                        String department = scanner.nextLine();
                        
                        StaffMember staff = new StaffMember(staffId, staffName, email, department);
                        inventoryManager.addStaffMember(staff);
                        System.out.println("Staff member registered successfully!");
                    } catch (NumberFormatException e) {
                        System.out.println("Error: Invalid staff ID.");
                    }
                    break;
                    
                case 3:
                    try {
                        System.out.print("Enter Staff ID: ");
                        int staffId = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter Equipment Asset ID: ");
                        String assetId = scanner.nextLine();
                        
                        StaffMember staff = inventoryManager.findStaffById(staffId);
                        Equipment equipment = inventoryManager.findEquipmentById(assetId);
                        
                        if (staff == null) {
                            throw new InventoryException("Staff not found.");
                        }
                        if (equipment == null) {
                            throw new InventoryException("Equipment not found.");
                        }
                        
                        inventoryManager.assignEquipment(staff, equipment);
                    } catch (NumberFormatException e) {
                        System.out.println("Error: Invalid staff ID.");
                    } catch (InventoryException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                    
                case 4:
                    try {
                        System.out.print("Enter Staff ID: ");
                        int staffId = Integer.parseInt(scanner.nextLine());
                        System.out.print("Enter Equipment Asset ID to return: ");
                        String assetId = scanner.nextLine();
                        
                        StaffMember staff = inventoryManager.findStaffById(staffId);
                        if (staff == null) {
                            throw new InventoryException("Staff not found.");
                        }
                        
                        inventoryManager.returnEquipment(staff, assetId);
                    } catch (NumberFormatException e) {
                        System.out.println("Error: Invalid staff ID.");
                    } catch (InventoryException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                    
                case 5:
                    System.out.print("Enter search term: ");
                    String searchTerm = scanner.nextLine();
                    List<Equipment> results = inventoryManager.searchEquipment(searchTerm);
                    
                    if (results.isEmpty()) {
                        System.out.println("No equipment found.");
                    } else {
                        System.out.println("Search Results:");
                        for (Equipment eq : results) {
                            System.out.println(eq);
                        }
                    }
                    break;
                    
                case 6:
                    System.out.println("\n--- REPORTS ---");
                    System.out.println("1. Inventory Report");
                    System.out.println("2. Expired Warranties");
                    System.out.println("3. Assignments by Department");
                    System.out.println("4. Utilisation Rate");
                    System.out.println("5. Maintenance Schedule");
                    System.out.print("Select report: ");
                    
                    try {
                        int reportChoice = Integer.parseInt(scanner.nextLine());
                        
                        if (reportChoice == 1) {
                            inventoryReports.generateInventoryReport();
                        } else if (reportChoice == 2) {
                            inventoryReports.findExpiredWarranties();
                        } else if (reportChoice == 3) {
                            inventoryReports.displayAssignmentsByDepartment();
                        } else if (reportChoice == 4) {
                            inventoryReports.calculateUtilisationRate();
                        } else if (reportChoice == 5) {
                            inventoryReports.generateMaintenanceSchedule();
                        } else {
                            System.out.println("Invalid report choice.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input.");
                    }
                    break;
                    
                case 7:
                    running = false;
                    System.out.println("Thank you for using the system. Goodbye!");
                    break;
                    
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }
}
