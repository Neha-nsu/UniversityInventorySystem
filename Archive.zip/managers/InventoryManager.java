package managers;

import models.Equipment;
import models.StaffMember;
import exceptions.InventoryException;
import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    
    private List<Equipment> equipmentList;
    private List<StaffMember> staffList;
    
    public InventoryManager() {
        this.equipmentList = new ArrayList<>();
        this.staffList = new ArrayList<>();
    }
    
    public void addEquipment(Equipment equipment) {
        if (equipment != null) {
            equipmentList.add(equipment);
        }
    }
    
    public void addStaffMember(StaffMember staff) {
        if (staff != null) {
            staffList.add(staff);
        }
    }
    
    public List<Equipment> getEquipmentList() {
        return equipmentList;
    }
    
    public List<StaffMember> getStaffList() {
        return staffList;
    }
    
    public void assignEquipment(StaffMember staff, Equipment equipment) throws InventoryException {
        validateAssignment(staff, equipment);
        
        if (!equipment.isAvailable()) {
            throw new InventoryException("Equipment '" + equipment.getName() + "' is not available.");
        } else {
            if (staff.getAssignedEquipmentCount() >= 5) {
                throw new InventoryException("Staff member has reached maximum limit of 5 items.");
            } else {
                if (staff.addAssignedEquipment(equipment)) {
                    equipment.setAvailable(false);
                    System.out.println("Successfully assigned '" + equipment.getName() + "' to " + staff.getName());
                } else {
                    System.out.println("Failed to assign equipment.");
                }
            }
        }
    }
    
    public boolean returnEquipment(StaffMember staff, String assetId) throws InventoryException {
        if (staff == null) {
            throw new InventoryException("Staff member cannot be null.");
        }
        
        if (assetId == null || assetId.trim().isEmpty()) {
            throw new InventoryException("Asset ID cannot be empty.");
        }
        
        if (!staff.hasEquipment(assetId)) {
            throw new InventoryException("Equipment not assigned to this staff member.");
        }
        
        Equipment returnedEquipment = staff.removeAssignedEquipment(assetId);
        
        if (returnedEquipment != null) {
            returnedEquipment.setAvailable(true);
            System.out.println("Equipment returned successfully.");
            return true;
        } else {
            return false;
        }
    }
    
    public double calculateMaintenanceFee(Equipment equipment, int daysOverdue) {
        if (daysOverdue <= 0) {
            return 0.0;
        }
        
        double dailyRate;
        String category = equipment.getCategory().toLowerCase();
        
        switch (category) {
            case "computer":
                dailyRate = 10.00;
                break;
            case "projector":
                dailyRate = 15.00;
                break;
            case "printer":
                dailyRate = 8.00;
                break;
            case "laboratory":
                dailyRate = 20.00;
                break;
            default:
                dailyRate = 5.00;
                break;
        }
        
        return dailyRate * daysOverdue;
    }
    
    public List<Equipment> searchEquipment(String name) {
        List<Equipment> results = new ArrayList<>();
        
        for (Equipment equipment : equipmentList) {
            if (equipment.getName().toLowerCase().contains(name.toLowerCase())) {
                results.add(equipment);
            }
        }
        
        return results;
    }
    
    public List<Equipment> searchEquipment(String category, boolean availableOnly) {
        List<Equipment> results = new ArrayList<>();
        
        for (Equipment equipment : equipmentList) {
            boolean categoryMatches = equipment.getCategory().toLowerCase().contains(category.toLowerCase());
            boolean availabilityMatches = !availableOnly || equipment.isAvailable();
            
            if (categoryMatches && availabilityMatches) {
                results.add(equipment);
            }
        }
        
        return results;
    }
    
    public List<Equipment> searchEquipment(int minWarranty, int maxWarranty) {
        List<Equipment> results = new ArrayList<>();
        
        for (Equipment equipment : equipmentList) {
            int warranty = equipment.getWarrantyMonths();
            if (warranty >= minWarranty && warranty <= maxWarranty) {
                results.add(equipment);
            }
        }
        
        return results;
    }
    
    public void validateAssignment(StaffMember staff, Equipment equipment) throws InventoryException {
        if (staff == null) {
            throw new InventoryException("Staff member cannot be null.");
        } else {
            if (equipment == null) {
                throw new InventoryException("Equipment cannot be null.");
            }
        }
    }
    
    public StaffMember findStaffById(int staffId) {
        for (StaffMember staff : staffList) {
            if (staff.getStaffId() == staffId) {
                return staff;
            }
        }
        return null;
    }
    
    public Equipment findEquipmentById(String assetId) {
        for (Equipment equipment : equipmentList) {
            if (equipment.getAssetId().equals(assetId)) {
                return equipment;
            }
        }
        return null;
    }
    
    public int getTotalEquipmentCount() {
        return equipmentList.size();
    }
    
    public int getAvailableEquipmentCount() {
        int count = 0;
        for (Equipment equipment : equipmentList) {
            if (equipment.isAvailable()) {
                count++;
            }
        }
        return count;
    }
    
    public int getTotalStaffCount() {
        return staffList.size();
    }
}
