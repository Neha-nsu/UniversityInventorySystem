package managers;

import models.Equipment;
import models.StaffMember;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

public class InventoryReports {
    
    private InventoryManager inventoryManager;
    
    public InventoryReports(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
    }
    
    public void generateInventoryReport() {
        System.out.println("\n======================================================================");
        System.out.println("           UNIVERSITY INVENTORY REPORT");
        System.out.println("======================================================================");
        
        List<Equipment> equipmentList = inventoryManager.getEquipmentList();
        
        if (equipmentList.isEmpty()) {
            System.out.println("No equipment in the inventory.");
            return;
        }
        
        System.out.println("\n--- Equipment Inventory ---");
        System.out.println("No.   Asset ID     Name                 Category     Available  Warranty");
        System.out.println("----------------------------------------------------------------------");
        
        for (int i = 0; i < equipmentList.size(); i++) {
            Equipment equipment = equipmentList.get(i);
            String warranty;
            if (equipment.getWarrantyMonths() > 0) {
                warranty = equipment.getWarrantyMonths() + " months";
            } else {
                warranty = "Expired";
            }
            
            System.out.printf("%-5d %-12s %-20s %-12s %-10s %-10s%n",
                (i + 1),
                equipment.getAssetId(),
                equipment.getName(),
                equipment.getCategory(),
                equipment.isAvailable() ? "Yes" : "No",
                warranty
            );
        }
        
        int totalCount = equipmentList.size();
        int availableCount = 0;
        int assignedCount = 0;
        
        for (int i = 0; i < totalCount; i++) {
            if (equipmentList.get(i).isAvailable()) {
                availableCount++;
            } else {
                assignedCount++;
            }
        }
        
        System.out.println("----------------------------------------------------------------------");
        System.out.println("\n--- Summary ---");
        System.out.println("Total Equipment: " + totalCount);
        System.out.println("Available: " + availableCount);
        System.out.println("Assigned: " + assignedCount);
        System.out.println("======================================================================");
    }
    
    public void findExpiredWarranties() {
        System.out.println("\n======================================================================");
        System.out.println("           EXPIRED WARRANTIES REPORT");
        System.out.println("======================================================================");
        
        List<Equipment> equipmentList = inventoryManager.getEquipmentList();
        
        if (equipmentList.isEmpty()) {
            System.out.println("No equipment in the inventory.");
            return;
        }
        
        List<Equipment> expiredEquipment = new ArrayList<>();
        
        int index = 0;
        while (index < equipmentList.size()) {
            Equipment equipment = equipmentList.get(index);
            
            if (equipment.getWarrantyMonths() == 0) {
                expiredEquipment.add(equipment);
            }
            
            index++;
        }
        
        if (expiredEquipment.isEmpty()) {
            System.out.println("\nGood news! No equipment has expired warranties.");
        } else {
            System.out.println("\n--- Equipment with Expired Warranties ---");
            System.out.println("Asset ID     Name                      Category        Available");
            System.out.println("----------------------------------------------------------------------");
            
            int expiredIndex = 0;
            while (expiredIndex < expiredEquipment.size()) {
                Equipment eq = expiredEquipment.get(expiredIndex);
                System.out.printf("%-12s %-25s %-15s %-12s%n",
                    eq.getAssetId(),
                    eq.getName(),
                    eq.getCategory(),
                    eq.isAvailable() ? "Yes" : "No"
                );
                expiredIndex++;
            }
            
            System.out.println("----------------------------------------------------------------------");
            System.out.println("Total equipment with expired warranties: " + expiredEquipment.size());
            System.out.println("\nAction Required: Schedule maintenance or replacement for these items.");
        }
        
        System.out.println("======================================================================");
    }
    
    public void displayAssignmentsByDepartment() {
        System.out.println("\n======================================================================");
        System.out.println("           EQUIPMENT ASSIGNMENTS BY DEPARTMENT");
        System.out.println("======================================================================");
        
        List<StaffMember> staffList = inventoryManager.getStaffList();
        
        if (staffList.isEmpty()) {
            System.out.println("No staff members in the system.");
            return;
        }
        
        Map<String, List<StaffMember>> departmentMap = new HashMap<>();
        
        for (StaffMember staff : staffList) {
            String department = staff.getDepartment();
            
            if (!departmentMap.containsKey(department)) {
                departmentMap.put(department, new ArrayList<>());
            }
            departmentMap.get(department).add(staff);
        }
        
        for (String department : departmentMap.keySet()) {
            System.out.println("\n--- Department: " + department + " ---");
            
            List<StaffMember> deptStaff = departmentMap.get(department);
            int totalAssignments = 0;
            
            for (StaffMember staff : deptStaff) {
                System.out.println("\n  Staff: " + staff.getName() + " (ID: " + staff.getStaffId() + ")");
                System.out.println("  Email: " + staff.getEmail());
                System.out.println("  Assigned Equipment: " + staff.getAssignedEquipmentCount() + "/5");
                
                Equipment[] assignedEquipment = staff.getAssignedEquipment();
                
                if (staff.getAssignedEquipmentCount() > 0) {
                    System.out.println("  Equipment List:");
                    
                    for (Equipment equipment : assignedEquipment) {
                        if (equipment != null) {
                            System.out.println("    - " + equipment.getName() + " (" + equipment.getAssetId() + ")");
                            totalAssignments++;
                        }
                    }
                } else {
                    System.out.println("  No equipment assigned.");
                }
            }
            
            System.out.println("\n  Department Total Assignments: " + totalAssignments);
        }
        
        System.out.println("\n======================================================================");
    }
    
    public void calculateUtilisationRate() {
        System.out.println("\n======================================================================");
        System.out.println("           EQUIPMENT UTILISATION STATISTICS");
        System.out.println("======================================================================");
        
        List<Equipment> equipmentList = inventoryManager.getEquipmentList();
        List<StaffMember> staffList = inventoryManager.getStaffList();
        
        if (equipmentList.isEmpty()) {
            System.out.println("No equipment in the inventory to calculate utilisation.");
            return;
        }
        
        int totalEquipment = equipmentList.size();
        int assignedEquipment = 0;
        int availableEquipment = 0;
        
        for (int i = 0; i < equipmentList.size(); i++) {
            Equipment equipment = equipmentList.get(i);
            boolean isAssigned = false;
            
            for (int j = 0; j < staffList.size(); j++) {
                StaffMember staff = staffList.get(j);
                Equipment[] staffEquipment = staff.getAssignedEquipment();
                
                for (int k = 0; k < staff.getAssignedEquipmentCount(); k++) {
                    if (staffEquipment[k] != null && 
                        staffEquipment[k].getAssetId().equals(equipment.getAssetId())) {
                        isAssigned = true;
                        break;
                    }
                }
                
                if (isAssigned) {
                    break;
                }
            }
            
            if (isAssigned || !equipment.isAvailable()) {
                assignedEquipment++;
            } else {
                availableEquipment++;
            }
        }
        
        double utilisationRate = (double) assignedEquipment / totalEquipment * 100;
        double availabilityRate = (double) availableEquipment / totalEquipment * 100;
        
        Map<String, int[]> categoryStats = new HashMap<>();
        
        for (int i = 0; i < equipmentList.size(); i++) {
            Equipment equipment = equipmentList.get(i);
            String category = equipment.getCategory();
            
            if (!categoryStats.containsKey(category)) {
                categoryStats.put(category, new int[]{0, 0});
            }
            
            int[] stats = categoryStats.get(category);
            stats[0]++;
            
            if (!equipment.isAvailable()) {
                stats[1]++;
            }
        }
        
        System.out.println("\n--- Overall Statistics ---");
        System.out.println("Total Equipment: " + totalEquipment);
        System.out.println("Assigned Equipment: " + assignedEquipment);
        System.out.println("Available Equipment: " + availableEquipment);
        System.out.printf("Utilisation Rate: %.2f%%%n", utilisationRate);
        System.out.printf("Availability Rate: %.2f%%%n", availabilityRate);
        
        System.out.println("\n--- Category-wise Utilisation ---");
        System.out.println("Category             Total      Assigned   Utilisation");
        System.out.println("-------------------------------------------------------");
        
        for (String category : categoryStats.keySet()) {
            int[] stats = categoryStats.get(category);
            double catUtilisation = 0;
            if (stats[0] > 0) {
                catUtilisation = (double) stats[1] / stats[0] * 100;
            }
            System.out.printf("%-20s %-10d %-10d %.2f%%%n", category, stats[0], stats[1], catUtilisation);
        }
        
        System.out.println("\n--- Staff Utilisation ---");
        System.out.println("Staff Name                Department       Assigned   Capacity Used");
        System.out.println("-----------------------------------------------------------------");
        
        for (int i = 0; i < staffList.size(); i++) {
            StaffMember staff = staffList.get(i);
            double capacityUsed = (double) staff.getAssignedEquipmentCount() / 5 * 100;
            System.out.printf("%-25s %-15s %-10d %.2f%%%n",
                staff.getName(),
                staff.getDepartment(),
                staff.getAssignedEquipmentCount(),
                capacityUsed
            );
        }
        
        System.out.println("\n======================================================================");
    }
    
    public void generateMaintenanceSchedule() {
        System.out.println("\n======================================================================");
        System.out.println("           MAINTENANCE SCHEDULE");
        System.out.println("======================================================================");
        
        List<Equipment> equipmentList = inventoryManager.getEquipmentList();
        
        if (equipmentList.isEmpty()) {
            System.out.println("No equipment in the inventory.");
            return;
        }
        
        List<String[]> scheduleEntries = new ArrayList<>();
        
        int index = 0;
        do {
            Equipment equipment = equipmentList.get(index);
            String priority;
            String scheduledDate;
            String maintenanceType;
            
            if (equipment.getWarrantyMonths() == 0) {
                priority = "HIGH";
                scheduledDate = "Within 7 days";
                maintenanceType = "Full Inspection";
            } else if (equipment.getWarrantyMonths() <= 3) {
                priority = "MEDIUM";
                scheduledDate = "Within 14 days";
                maintenanceType = "Preventive Check";
            } else if (!equipment.isAvailable()) {
                priority = "NORMAL";
                scheduledDate = "After Return";
                maintenanceType = "Routine Check";
            } else {
                priority = "LOW";
                scheduledDate = "Within 30 days";
                maintenanceType = "Routine Check";
            }
            
            scheduleEntries.add(new String[]{
                equipment.getAssetId(),
                equipment.getName(),
                equipment.getCategory(),
                priority,
                scheduledDate,
                maintenanceType
            });
            
            index++;
        } while (index < equipmentList.size());
        
        System.out.println("\n--- Scheduled Maintenance Activities ---");
        System.out.println("Asset ID     Name                 Category     Priority Schedule        Type");
        System.out.println("-------------------------------------------------------------------------------------");
        
        String[] priorities = {"HIGH", "MEDIUM", "NORMAL", "LOW"};
        int priorityIndex = 0;
        
        do {
            String currentPriority = priorities[priorityIndex];
            boolean headerPrinted = false;
            
            int entryIndex = 0;
            do {
                String[] entry = scheduleEntries.get(entryIndex);
                
                if (entry[3].equals(currentPriority)) {
                    if (!headerPrinted) {
                        System.out.println("\n[" + currentPriority + " PRIORITY]");
                        headerPrinted = true;
                    }
                    
                    System.out.printf("%-12s %-20s %-12s %-8s %-15s %-18s%n",
                        entry[0], entry[1], entry[2], entry[3], entry[4], entry[5]
                    );
                }
                
                entryIndex++;
            } while (entryIndex < scheduleEntries.size());
            
            priorityIndex++;
        } while (priorityIndex < priorities.length);
        
        System.out.println("\n--- Maintenance Summary ---");
        int highCount = 0, mediumCount = 0, normalCount = 0, lowCount = 0;
        
        int countIndex = 0;
        do {
            String priority = scheduleEntries.get(countIndex)[3];
            switch (priority) {
                case "HIGH": highCount++; break;
                case "MEDIUM": mediumCount++; break;
                case "NORMAL": normalCount++; break;
                case "LOW": lowCount++; break;
            }
            countIndex++;
        } while (countIndex < scheduleEntries.size());
        
        System.out.println("High Priority Items: " + highCount);
        System.out.println("Medium Priority Items: " + mediumCount);
        System.out.println("Normal Priority Items: " + normalCount);
        System.out.println("Low Priority Items: " + lowCount);
        
        System.out.println("\n======================================================================");
    }
}
